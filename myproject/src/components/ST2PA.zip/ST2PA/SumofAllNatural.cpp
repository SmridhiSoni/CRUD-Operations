#include<iostream>
using namespace std;
int main(){
//    int n;
//     cin>>n;
//      int sum=0;
//     for(int i=1;i<=n;i++){
//         sum+=i;
       
//     }
//      cout<<"The sum is: "<<sum;
// }
int n;
cin>>n;
int ans;
for(int i=1;i<n;i++){
     ans=(n*(n+1))/2;

}
cout<<ans;
}

